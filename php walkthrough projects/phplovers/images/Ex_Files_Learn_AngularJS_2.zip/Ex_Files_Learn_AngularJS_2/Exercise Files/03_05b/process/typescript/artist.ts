export interface Artist {
    name: string;
    shortname: string;
    reknown: string;
    bio: string;
}
