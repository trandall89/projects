import {Component} from 'angular2/core';

@Component({
  selector: 'my-app',
  template: '<h1>Welcome to my App</h1>'
})

export class AppComponent {

}
